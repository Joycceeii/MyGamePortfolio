using UnityEngine;

public class MovingReservoir : MonoBehaviour
{
    [SerializeField] private float amplitude = 2.4f;
    [SerializeField, Min(1f)] private float period = 10f;
    private Vector3 origin;
    private float elapsed;
    private void Awake()
    {
        origin = transform.position;
        elapsed = 0f;
    }
    private void FixedUpdate()
    {
        if (GameManager.Instance == null || !GameManager.Instance.RoundStarted) return;
        elapsed += Time.fixedDeltaTime;
        float phase = elapsed * Mathf.PI * 2f / period;
        transform.position = origin + Vector3.right * (Mathf.Sin(phase) * amplitude);
    }
}
