using System;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }
    [SerializeField, Min(1)] private int totalDrops = 15;
    [SerializeField, Min(1)] private int dropsNeededToWin = 10;
    [SerializeField] private string levelTitle = "Waterline";
    [SerializeField, TextArea] private string levelHint = "Draw ramps to guide water into the cup.";
    [SerializeField] private string nextSceneName = "";
    [SerializeField] private string firstSceneName = "Waterline_Tutorial";

    private int collectedDrops;
    private int lostDrops;
    public int CollectedDrops => collectedDrops;
    public int LostDrops => lostDrops;
    public int TotalDrops => totalDrops;
    public int DropsNeededToWin => dropsNeededToWin;
    public string LevelTitle => levelTitle;
    public string LevelHint => levelHint;
    public bool GameEnded { get; private set; }
    public bool RoundStarted { get; private set; }
    public bool PlayerWon { get; private set; }
    public bool HasNextLevel => !string.IsNullOrEmpty(nextSceneName);
    public event Action<int, int, int> ScoreChanged;
    public event Action<bool> RoundEnded;

    private void Awake()
    {
        Instance = this;
        totalDrops = Mathf.Max(1, totalDrops);
        dropsNeededToWin = Mathf.Clamp(dropsNeededToWin, 1, totalDrops);
        Time.timeScale = 1f;
    }
    private void Start() => PublishScore();
    private void OnEnable()
    {
        WaterDrop.DropletCollected += HandleDropCollected;
        WaterDrop.DropletLost += HandleDropLost;
    }
    private void OnDisable()
    {
        WaterDrop.DropletCollected -= HandleDropCollected;
        WaterDrop.DropletLost -= HandleDropLost;
    }
    private void OnDestroy()
    {
        if (Instance == this) Instance = null;
    }
    private void Update()
    {
        if (Keyboard.current == null) return;
        if (Keyboard.current.rKey.wasPressedThisFrame) RestartGame();
        else if (GameEnded && Keyboard.current.enterKey.wasPressedThisFrame) ContinueGame();
    }
    public void BeginRound()
    {
        if (!GameEnded) RoundStarted = true;
    }
    private void HandleDropCollected(WaterDrop drop)
    {
        if (GameEnded) return;
        collectedDrops++;
        PublishScore();
        if (collectedDrops >= dropsNeededToWin) EndRound(true);
    }
    private void HandleDropLost(WaterDrop drop)
    {
        if (GameEnded) return;
        lostDrops++;
        PublishScore();
        if (lostDrops > totalDrops - dropsNeededToWin) EndRound(false);
    }
    private void PublishScore() => ScoreChanged?.Invoke(collectedDrops, lostDrops, dropsNeededToWin);
    private void EndRound(bool won)
    {
        if (GameEnded) return;
        GameEnded = true;
        PlayerWon = won;
        Time.timeScale = 0f;
        RoundEnded?.Invoke(won);
    }
    public void RestartGame() => LoadLevel(SceneManager.GetActiveScene().name);
    public void ContinueGame()
    {
        if (!GameEnded) return;
        LoadLevel(PlayerWon ? (HasNextLevel ? nextSceneName : firstSceneName)
                            : SceneManager.GetActiveScene().name);
    }
    private void LoadLevel(string sceneName)
    {
        if (!Application.CanStreamedLevelBeLoaded(sceneName))
        {
            Debug.LogError("Missing scene in Build Profiles: " + sceneName);
            return;
        }
        Time.timeScale = 1f;
        SceneManager.LoadScene(sceneName);
    }
}
