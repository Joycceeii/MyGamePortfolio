using UnityEditor;
public static class WaterlineValidation
{
    [MenuItem("Tools/Waterline/Validate Scene Wiring")]
    public static void Validate() => WaterlineBuild.ValidateScenes();
}
