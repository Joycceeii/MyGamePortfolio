using UnityEngine;

public class ReservoirFill : MonoBehaviour
{
    private GameManager manager;
    private Transform fill;
    private Sprite ownedSprite;
    private Texture2D ownedTexture;
    private float shown;
    private float target;
    private void Start()
    {
        manager = GameManager.Instance;
        if (manager == null) return;
        ownedTexture = new Texture2D(1, 1);
        ownedTexture.SetPixel(0, 0, Color.white);
        ownedTexture.Apply();
        ownedSprite = Sprite.Create(ownedTexture, new Rect(0, 0, 1, 1), new Vector2(0.5f, 0f), 1f);
        GameObject water = new GameObject("CollectedWater");
        fill = water.transform;
        fill.SetParent(transform, false);
        fill.localPosition = new Vector3(0f, -0.59f, 0f);
        var renderer = water.AddComponent<SpriteRenderer>();
        renderer.sprite = ownedSprite;
        var wall = transform.Find("Bottom");
        if (wall != null && wall.TryGetComponent(out SpriteRenderer wallRenderer))
            renderer.sharedMaterial = wallRenderer.sharedMaterial;
        renderer.color = new Color(0.16f, 0.65f, 0.95f, 0.7f);
        renderer.sortingOrder = 2;
        fill.localScale = new Vector3(1.55f, 0f, 1f);
        manager.ScoreChanged += OnScore;
        OnScore(manager.CollectedDrops, manager.LostDrops, manager.DropsNeededToWin);
    }
    private void OnScore(int collected, int lost, int goal)
    {
        target = Mathf.Clamp01((float)collected / Mathf.Max(1, goal)) * 1.05f;
    }
    private void Update()
    {
        if (fill == null) return;
        shown = Mathf.MoveTowards(shown, target, Time.unscaledDeltaTime * 1.5f);
        fill.localScale = new Vector3(1.55f, shown, 1f);
    }
    private void OnDestroy()
    {
        if (manager != null) manager.ScoreChanged -= OnScore;
        if (ownedSprite != null) Destroy(ownedSprite);
        if (ownedTexture != null) Destroy(ownedTexture);
    }
}
