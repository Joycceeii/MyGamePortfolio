using UnityEngine;
using UnityEngine.InputSystem;

public class DrawController : MonoBehaviour
{
    [SerializeField] private Camera drawingCamera;
    [SerializeField] private TemporaryLine temporaryLinePrefab;
    [SerializeField] private GameObject drawingGuide;

    private TemporaryLine activeLine;
    private InputAction pressAction;
    private Vector2 pressPosition;
    private bool pendingPress;

    private void Awake()
    {
        if (drawingCamera == null)
        {
            drawingCamera = Camera.main;
        }
        pressAction = new InputAction("Begin drawing", InputActionType.Button, "<Mouse>/leftButton");
        pressAction.started += RememberPress;
    }

    private void OnEnable() => pressAction.Enable();

    private void OnDisable()
    {
        pressAction.Disable();
        pendingPress = false;
    }

    private void OnDestroy() => pressAction.Dispose();

    private void RememberPress(InputAction.CallbackContext context)
    {
        if (Mouse.current == null) return;
        pressPosition = Mouse.current.position.ReadValue();
        pendingPress = true;
    }

    private void Update()
    {
        if (Mouse.current == null || drawingCamera == null ||
            (GameManager.Instance != null && GameManager.Instance.GameEnded))
        {
            return;
        }

        Vector2 screenPosition = Mouse.current.position.ReadValue();

        Vector3 worldPosition3D =
            drawingCamera.ScreenToWorldPoint(screenPosition);

        Vector2 worldPosition =
            new Vector2(worldPosition3D.x, worldPosition3D.y);

        if (pendingPress)
        {
            pendingPress = false;
            if (pressPosition.x >= 0 && pressPosition.x <= Screen.width &&
                pressPosition.y >= 0 && pressPosition.y <= Screen.height)
            {
                Vector3 start = drawingCamera.ScreenToWorldPoint(pressPosition);
                StartDrawing(new Vector2(start.x, start.y));
            }
        }

        if (Mouse.current.leftButton.isPressed && activeLine != null)
        {
            bool canContinue = activeLine.AddPoint(worldPosition);
            NotifyUsefulStroke();

            if (!canContinue)
            {
                activeLine = null;
            }
        }

        if (Mouse.current.leftButton.wasReleasedThisFrame)
        {
            // Keep even a fast press-and-release stroke's final segment.
            if (activeLine != null) activeLine.AddPoint(worldPosition);
            StopDrawing();
        }
    }

    private void StartDrawing(Vector2 worldPosition)
    {
        if (activeLine != null)
        {
            activeLine.FinishLine();
        }

        activeLine = Instantiate(
            temporaryLinePrefab,
            Vector3.zero,
            Quaternion.identity
        );

        activeLine.BeginLine(worldPosition);
    }

    private void StopDrawing()
    {
        if (activeLine == null)
        {
            return;
        }

        NotifyUsefulStroke();
        activeLine.FinishLine();
        activeLine = null;
    }

    private void NotifyUsefulStroke()
    {
        if (activeLine == null || activeLine.Length < 0.1f) return;
        if (drawingGuide != null) drawingGuide.SetActive(false);
        if (GameManager.Instance != null) GameManager.Instance.BeginRound();
    }
}