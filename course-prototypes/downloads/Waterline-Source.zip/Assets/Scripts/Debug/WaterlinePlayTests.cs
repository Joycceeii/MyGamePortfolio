using System;
using System.Collections;
using System.IO;
using System.Reflection;
using UnityEngine;
using UnityEngine.SceneManagement;

// Activated only with the explicit -waterline-validate command-line flag.
public class WaterlinePlayTests : MonoBehaviour
{
    private static string report = "";
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Install()
    {
        if (Array.IndexOf(Environment.GetCommandLineArgs(), "-waterline-validate") < 0) return;
        var runner = new GameObject("WaterlineValidation");
        DontDestroyOnLoad(runner);
        runner.AddComponent<WaterlinePlayTests>();
    }
    private IEnumerator Start()
    {
        IEnumerator tests = Tests();
        while (true)
        {
            bool more;
            object next = null;
            try { more = tests.MoveNext(); if (more) next = tests.Current; }
            catch (Exception error) { Finish(false, error.ToString()); yield break; }
            if (!more) { Finish(true, ""); yield break; }
            yield return next;
        }
    }
    private static void Finish(bool success, string error)
    {
        string[] args = Environment.GetCommandLineArgs();
        int index = Array.IndexOf(args, "-waterline-report");
        string path = index >= 0 && index + 1 < args.Length ? args[index + 1]
            : Path.Combine(Application.persistentDataPath, "WaterlinePlayTests.txt");
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path)));
        File.WriteAllText(path, report + "\n" + error);
        Debug.Log(success ? "WATERLINE_PLAYTESTS_OK\n" + report : "WATERLINE_PLAYTESTS_FAILED\n" + error);
        Application.Quit(success ? 0 : 1);
    }
    private static void Check(bool condition, string label)
    {
        if (!condition) throw new Exception(label);
        report += "PASS: " + label + "\n";
    }
    private static void Draw(params Vector2[] path)
    {
        DrawController controller = UnityEngine.Object.FindFirstObjectByType<DrawController>();
        typeof(DrawController).GetMethod("StartDrawing", BindingFlags.Instance | BindingFlags.NonPublic)
            .Invoke(controller, new object[] { path[0] });
        var line = (TemporaryLine)typeof(DrawController).GetField("activeLine", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(controller);
        for (int segment = 1; segment < path.Length; segment++)
        {
            Vector2 a=path[segment-1], b=path[segment];
            int steps = Mathf.CeilToInt(Vector2.Distance(a,b) / 0.1f);
            for (int i=1;i<=steps;i++) line.AddPoint(Vector2.Lerp(a,b,(float)i/steps));
        }
        typeof(DrawController).GetMethod("StopDrawing", BindingFlags.Instance | BindingFlags.NonPublic)
            .Invoke(controller, null);
    }
    private static IEnumerator Tests()
    {
        Application.runInBackground = true;
        Time.captureDeltaTime = 1f / 60f;
        QualitySettings.vSyncCount = 0;
        Application.targetFrameRate = 120;
        yield return null;
        yield return null;
        Check(GameManager.Instance.TotalDrops == 5 && GameManager.Instance.DropsNeededToWin == 3, "tutorial goal 3/5");
        Check(!GameManager.Instance.RoundStarted && UnityEngine.Object.FindObjectsByType<WaterDrop>(FindObjectsSortMode.None).Length == 0, "water waits for first drawing");
        GameObject guide = GameObject.Find("DrawingGuide");
        Check(guide != null && guide.GetComponent<Collider2D>() == null, "visual guide has no collider");
        Check(Mathf.Abs(guide.GetComponent<LineRenderer>().startColor.a - 0.3f) < 0.01f, "guide alpha 0.3");
        Draw(new Vector2(-2.8f, 1.5f), new Vector2(1f, -2.2f));
        Check(!guide.activeSelf, "first stroke hides guide");
        Check(GameManager.Instance.RoundStarted, "drawing begins the round");
        float startedGameTime = Time.time;
        float deadline = Time.realtimeSinceStartup + 20f;
        while (!GameManager.Instance.GameEnded && Time.realtimeSinceStartup < deadline) yield return null;
        Check(GameManager.Instance.PlayerWon, "tutorial physically playable with demonstrated ramp (collected=" + GameManager.Instance.CollectedDrops + ", lost=" + GameManager.Instance.LostDrops + ", gameTime=" + Time.time + ", drops=" + UnityEngine.Object.FindObjectsByType<WaterDrop>(FindObjectsSortMode.None).Length + ")");
        var fill = GameObject.Find("CollectedWater");
        Check(fill != null, "reservoir water fill exists");
        GameManager.Instance.RestartGame();
        yield return null; yield return null; yield return null;
        Check(SceneManager.GetActiveScene().name == "Waterline_Tutorial" && !GameManager.Instance.GameEnded, "restart resets score and round");
        Check(GameObject.Find("DrawingGuide") != null, "restart restores guide");
        Draw(new Vector2(-7f, -4f), new Vector2(-6f, -4f));
        deadline = Time.realtimeSinceStartup + 20f;
        while (!GameManager.Instance.GameEnded && Time.realtimeSinceStartup < deadline) yield return null;
        Check(GameManager.Instance.GameEnded && !GameManager.Instance.PlayerWon, "missing water produces a reachable loss");
        GameManager.Instance.ContinueGame();
        yield return null; yield return null; yield return null;
        Check(SceneManager.GetActiveScene().name == "Waterline_Tutorial", "loss action retries current level");
        // Drive score events through actual droplet Collect, then verify next-level scene routing.
        var spawner = UnityEngine.Object.FindFirstObjectByType<DropSpawner>();
        var prefab = (GameObject)typeof(DropSpawner).GetField("waterDropPrefab",
            BindingFlags.Instance | BindingFlags.NonPublic).GetValue(spawner);
        for (int i=0;i<3;i++) UnityEngine.Object.Instantiate(prefab).GetComponent<WaterDrop>().Collect();
        GameManager.Instance.ContinueGame();
        yield return null; yield return null; yield return null;
        Check(SceneManager.GetActiveScene().name == "Waterline_Relay", "tutorial continues to relay");
        Draw(new Vector2(-5.4f,2f), new Vector2(1f,-1.3f));
        Draw(new Vector2(0.7f,-1.05f), new Vector2(3.8f,-1.3f), new Vector2(4.5f,-2.2f));
        float renew = Time.time + 3f;
        deadline = Time.realtimeSinceStartup + 25f;
        while (!GameManager.Instance.GameEnded && Time.realtimeSinceStartup < deadline)
        {
            if (Time.time >= renew)
            {
                Draw(new Vector2(-5.4f,2f), new Vector2(1f,-1.3f));
                Draw(new Vector2(0.7f,-1.05f), new Vector2(3.8f,-1.3f), new Vector2(4.5f,-2.2f));
                renew = Time.time + 3f;
            }
            yield return null;
        }
        Check(GameManager.Instance.PlayerWon, "relay physically playable using two maintained ramps (collected=" + GameManager.Instance.CollectedDrops + ", lost=" + GameManager.Instance.LostDrops + ", gameTime=" + Time.time + ", drops=" + UnityEngine.Object.FindObjectsByType<WaterDrop>(FindObjectsSortMode.None).Length + ")");
        GameManager.Instance.ContinueGame();
        yield return null; yield return null; yield return null;
        Check(SceneManager.GetActiveScene().name == "Waterline_Timing", "relay continues to timing");
        var cup = UnityEngine.Object.FindFirstObjectByType<MovingReservoir>();
        Check(cup != null && cup.enabled, "timing has moving reservoir");
        Draw(new Vector2(-2.8f,1.5f), new Vector2(2.4f,-1.3f));
        float initialX=cup.transform.position.x;
        float until=Time.time+0.5f;
        while (Time.time < until) yield return null;
        Check(Mathf.Abs(cup.transform.position.x-initialX)>0.1f, "reservoir actually moves during play");
        // Controlled deliveries test the moving collector and final loop independently of strategy.
        for (int i=0;i<7;i++)
        {
            var drop=UnityEngine.Object.Instantiate(prefab,cup.transform.position,Quaternion.identity);
            var body=drop.GetComponent<Rigidbody2D>(); body.gravityScale=0f;
            yield return null; yield return null;
        }
        deadline=Time.realtimeSinceStartup+4f;
        while (!GameManager.Instance.GameEnded && Time.realtimeSinceStartup<deadline) yield return null;
        Check(GameManager.Instance.PlayerWon, "moving cup trigger collects deliveries and completes campaign");
        GameManager.Instance.ContinueGame();
        yield return null; yield return null; yield return null;
        Check(SceneManager.GetActiveScene().name=="Waterline_Tutorial" && Time.timeScale==1f, "final action restarts entire campaign");
    }
}
