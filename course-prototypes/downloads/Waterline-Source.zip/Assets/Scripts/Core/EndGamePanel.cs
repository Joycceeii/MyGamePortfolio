using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class EndGamePanel : MonoBehaviour
{
    [SerializeField] private GameObject panel;
    [SerializeField] private TMP_Text titleText;
    [SerializeField] private TMP_Text resultText;
    [SerializeField] private Button restartButton;
    private GameManager gameManager;
    private TMP_Text buttonText;

    private void Start()
    {
        panel.SetActive(false);
        gameManager = GameManager.Instance;
        if (gameManager == null) return;
        buttonText = restartButton.GetComponentInChildren<TMP_Text>(true);
        gameManager.RoundEnded += HandleRoundEnded;
        restartButton.onClick.AddListener(ContinueGame);
    }
    private void OnDestroy()
    {
        if (gameManager != null) gameManager.RoundEnded -= HandleRoundEnded;
        if (restartButton != null) restartButton.onClick.RemoveListener(ContinueGame);
    }
    private void HandleRoundEnded(bool won)
    {
        panel.SetActive(true);
        titleText.text = won ? (gameManager.HasNextLevel ? "LEVEL COMPLETE!" : "WATERLINE COMPLETE!")
                             : "TRY ANOTHER ROUTE";
        titleText.enableAutoSizing = true;
        titleText.fontSizeMin = 18;
        titleText.fontSizeMax = 40;
        resultText.text = $"Collected {gameManager.CollectedDrops} / {gameManager.DropsNeededToWin}\nR: retry this level";
        resultText.enableAutoSizing = true;
        resultText.fontSizeMin = 14;
        resultText.fontSizeMax = 24;
        if (buttonText != null)
            buttonText.text = won ? (gameManager.HasNextLevel ? "Next Level" : "Play From Start") : "Try Again";
    }
    private void ContinueGame() => gameManager.ContinueGame();
}
