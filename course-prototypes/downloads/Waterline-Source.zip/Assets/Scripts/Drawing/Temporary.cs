using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(LineRenderer))]
[RequireComponent(typeof(EdgeCollider2D))]
public class TemporaryLine : MonoBehaviour
{
    [SerializeField] private float lifetime = 4f;
    [SerializeField] private float fadeDuration = 0.75f;
    [SerializeField] private float minimumPointDistance = 0.08f;
    [SerializeField] private float maximumLength = 8f;

    private readonly List<Vector2> points = new List<Vector2>();

    private LineRenderer lineRenderer;
    private EdgeCollider2D edgeCollider;

    private float totalLength;
    private float finishedTime;
    private bool finished;

    public bool IsFinished => finished;
    public float Length => totalLength;

    private void Awake()
    {
        lineRenderer = GetComponent<LineRenderer>();
        edgeCollider = GetComponent<EdgeCollider2D>();
    }

    public void BeginLine(Vector2 worldPoint)
    {
        points.Clear();
        totalLength = 0f;
        finished = false;

        Vector2 localPoint = transform.InverseTransformPoint(worldPoint);

        // EdgeCollider2D 至少需要两个不同的点。
        points.Add(localPoint);
        points.Add(localPoint + Vector2.right * 0.01f);

        RefreshLine();
    }

    public bool AddPoint(Vector2 worldPoint)
    {
        if (finished)
        {
            return false;
        }

        Vector2 localPoint = transform.InverseTransformPoint(worldPoint);
        Vector2 previousPoint = points[points.Count - 1];

        float segmentLength = Vector2.Distance(previousPoint, localPoint);

        if (segmentLength < minimumPointDistance)
        {
            return true;
        }

        float remainingLength = maximumLength - totalLength;

        if (segmentLength >= remainingLength)
        {
            localPoint = previousPoint
                + (localPoint - previousPoint).normalized * remainingLength;

            points.Add(localPoint);
            totalLength = maximumLength;
            RefreshLine();
            FinishLine();

            return false;
        }

        points.Add(localPoint);
        totalLength += segmentLength;
        RefreshLine();

        return true;
    }

    public void FinishLine()
    {
        if (finished)
        {
            return;
        }

        finished = true;
        finishedTime = Time.time;

        if (totalLength < 0.1f)
        {
            Destroy(gameObject);
        }
    }

    private void RefreshLine()
    {
        lineRenderer.positionCount = points.Count;

        for (int i = 0; i < points.Count; i++)
        {
            lineRenderer.SetPosition(
                i,
                transform.TransformPoint(points[i])
            );
        }

        edgeCollider.SetPoints(points);
    }

    private void Update()
    {
        if (!finished)
        {
            return;
        }

        float age = Time.time - finishedTime;
        float remainingTime = lifetime - age;

        if (remainingTime <= 0f)
        {
            Destroy(gameObject);
            return;
        }

        if (fadeDuration > 0f && remainingTime <= fadeDuration)
        {
            float progress = 1f - remainingTime / fadeDuration;

            // 每秒闪烁三次，提示线条即将消失。
            float pulse = 0.5f + 0.5f * Mathf.Cos(
                progress * fadeDuration * Mathf.PI * 6f
            );

            // 闪烁时仍然保持可见，最后逐渐变淡。
            float fade = Mathf.Clamp01(remainingTime / 0.25f);
            float alpha = Mathf.Lerp(0.35f, 1f, pulse) * fade;

            Color startColor = lineRenderer.startColor;
            Color endColor = lineRenderer.endColor;

            startColor.a = alpha;
            endColor.a = alpha;

            lineRenderer.startColor = startColor;
            lineRenderer.endColor = endColor;
        }
    }
}