using System.Collections;
using UnityEngine;

public class DropSpawner : MonoBehaviour
{
    [SerializeField] private GameObject waterDropPrefab;
    [SerializeField] private Transform spawnPoint;
    [SerializeField] private float firstDropDelay = 1f;
    [SerializeField] private float spawnInterval = 0.8f;
    [SerializeField] private int totalDrops = 15;
    private Coroutine spawnRoutine;
    private void Start() => RestartSpawning();
    public void RestartSpawning()
    {
        if (spawnRoutine != null) StopCoroutine(spawnRoutine);
        spawnRoutine = StartCoroutine(SpawnDrops());
    }
    private IEnumerator SpawnDrops()
    {
        while (GameManager.Instance != null && !GameManager.Instance.RoundStarted)
            yield return null;
        yield return new WaitForSeconds(Mathf.Max(0f, firstDropDelay));
        int count = GameManager.Instance != null ? GameManager.Instance.TotalDrops : totalDrops;
        for (int i = 0; i < count; i++)
        {
            if (GameManager.Instance != null && GameManager.Instance.GameEnded) break;
            Instantiate(waterDropPrefab, spawnPoint.position, Quaternion.identity);
            yield return new WaitForSeconds(Mathf.Max(0.1f, spawnInterval));
        }
        spawnRoutine = null;
    }
}
