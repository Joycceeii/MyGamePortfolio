using System;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Collider2D))]
public class WaterDrop : MonoBehaviour
{
    public static event Action<WaterDrop> DropletLost;
    public static event Action<WaterDrop> DropletCollected;
    private static readonly HashSet<WaterDrop> activeDrops = new HashSet<WaterDrop>();
    [SerializeField] private float destroyY = -6f;
    [SerializeField, Min(1f)] private float maximumLifetime = 25f;
    private Collider2D dropCollider;
    private float bornAt;
    private bool resolved;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    private static void ResetStatics() => activeDrops.Clear();
    private void OnEnable()
    {
        resolved = false;
        bornAt = Time.time;
        dropCollider = GetComponent<Collider2D>();
        foreach (WaterDrop other in activeDrops)
            if (other != null && other.dropCollider != null)
                Physics2D.IgnoreCollision(dropCollider, other.dropCollider);
        activeDrops.Add(this);
    }
    private void OnDisable() => activeDrops.Remove(this);
    private void Update()
    {
        if (!resolved && (transform.position.y < destroyY ||
            Mathf.Abs(transform.position.x) > 14f || Time.time - bornAt >= maximumLifetime))
            ResolveAsLost();
    }
    public void Collect()
    {
        if (resolved) return;
        resolved = true;
        DropletCollected?.Invoke(this);
        Destroy(gameObject);
    }
    private void ResolveAsLost()
    {
        if (resolved) return;
        resolved = true;
        DropletLost?.Invoke(this);
        Destroy(gameObject);
    }
}
