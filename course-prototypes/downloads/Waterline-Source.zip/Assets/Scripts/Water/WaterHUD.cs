using TMPro;
using UnityEngine;

public class WaterHUD : MonoBehaviour
{
    [SerializeField] private TMP_Text waterText;
    [SerializeField] private TMP_Text lostText;
    private GameManager gameManager;
    private TMP_Text instructionText;
    private bool shownStarted;

    private void Start()
    {
        gameManager = GameManager.Instance;
        if (gameManager == null) return;
        foreach (TMP_Text text in GetComponentsInChildren<TMP_Text>(true))
            if (text.name == "InstructionText") instructionText = text;
        if (instructionText != null)
        {
            instructionText.enableAutoSizing = true;
            instructionText.fontSizeMin = 14;
            instructionText.fontSizeMax = 22;
            instructionText.raycastTarget = false;
        }
        foreach (UnityEngine.UI.Graphic graphic in GetComponentsInChildren<UnityEngine.UI.Graphic>(true))
            graphic.raycastTarget = false;
        gameManager.ScoreChanged += HandleScoreChanged;
        gameManager.RoundEnded += HandleRoundEnded;
        HandleScoreChanged(gameManager.CollectedDrops, gameManager.LostDrops, gameManager.DropsNeededToWin);
        RefreshInstructions();
    }
    private void Update()
    {
        if (!shownStarted && gameManager != null && gameManager.RoundStarted)
        {
            shownStarted = true;
            RefreshInstructions();
        }
    }
    private void RefreshInstructions()
    {
        if (instructionText == null) return;
        string action = shownStarted ? "R: retry" : "Drag with left mouse to begin";
        instructionText.text = $"{gameManager.LevelTitle}  |  {action}\n{gameManager.LevelHint}";
    }
    private void OnDestroy()
    {
        if (gameManager == null) return;
        gameManager.ScoreChanged -= HandleScoreChanged;
        gameManager.RoundEnded -= HandleRoundEnded;
    }
    private void HandleScoreChanged(int collected, int lost, int target)
    {
        waterText.text = $"Water: {collected} / {target}";
        lostText.text = $"Lost: {lost} / {gameManager.TotalDrops - target}";
    }
    private void HandleRoundEnded(bool won) => gameObject.SetActive(false);
}
