using UnityEngine;

public class WaterCollector : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.TryGetComponent(out WaterDrop waterDrop))
        {
            waterDrop.Collect();
        }
    }
}